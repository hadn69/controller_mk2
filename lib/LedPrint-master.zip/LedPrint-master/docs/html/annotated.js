var annotated =
[
    [ "LedControl", "class_led_control.html", "class_led_control" ],
    [ "LedPrint", "class_led_print.html", "class_led_print" ],
    [ "LedPrintJustifiable", "class_led_print_justifiable.html", "class_led_print_justifiable" ]
];