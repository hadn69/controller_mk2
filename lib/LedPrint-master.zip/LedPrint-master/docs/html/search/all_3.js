var searchData=
[
  ['justify',['justify',['../class_led_print_justifiable.html#ae1cbaec743b721679f09faa4921d7f21',1,'LedPrintJustifiable']]],
  ['justifybuffer',['justifyBuffer',['../class_led_print_justifiable.html#a0d0a2b946741ae08781f36a1f971872d',1,'LedPrintJustifiable']]]
];
