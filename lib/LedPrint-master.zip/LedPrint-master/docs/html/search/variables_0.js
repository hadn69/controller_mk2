var searchData=
[
  ['justifybuffer',['justifyBuffer',['../class_led_print_justifiable.html#a0d0a2b946741ae08781f36a1f971872d',1,'LedPrintJustifiable']]]
];
