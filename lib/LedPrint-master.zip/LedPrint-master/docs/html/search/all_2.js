var searchData=
[
  ['getjustifiedsubdisplay',['getJustifiedSubDisplay',['../class_led_print.html#a7c30839e6b8a92166c8d7eddfa4f0c49',1,'LedPrint']]],
  ['getsubdisplay',['getSubDisplay',['../class_led_print.html#a7f378d6f3b5fa17ef215b9a42dd5a359',1,'LedPrint::getSubDisplay()'],['../class_led_print_justifiable.html#a8d7d512b8caefc5702fbef6b293bed1d',1,'LedPrintJustifiable::getSubDisplay()']]]
];
