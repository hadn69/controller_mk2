var searchData=
[
  ['justify',['justify',['../class_led_print_justifiable.html#ae1cbaec743b721679f09faa4921d7f21',1,'LedPrintJustifiable']]]
];
