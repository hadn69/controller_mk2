var hierarchy =
[
    [ "LedControl", "class_led_control.html", null ],
    [ "Print", null, [
      [ "LedPrint", "class_led_print.html", [
        [ "LedPrintJustifiable", "class_led_print_justifiable.html", null ]
      ] ]
    ] ]
];